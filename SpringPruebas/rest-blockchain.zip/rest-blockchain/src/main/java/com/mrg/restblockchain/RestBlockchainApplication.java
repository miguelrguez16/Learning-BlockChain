package com.mrg.restblockchain;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestBlockchainApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestBlockchainApplication.class, args);
	}

}
