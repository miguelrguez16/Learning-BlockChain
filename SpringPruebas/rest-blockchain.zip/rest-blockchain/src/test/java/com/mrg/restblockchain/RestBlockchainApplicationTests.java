package com.mrg.restblockchain;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestBlockchainApplicationTests {

	@Test
	void contextLoads() {
	}

}
